import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Brain, BookOpen, Calendar, Heart, Shield, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';

export default function Index() {
  const navigate = useNavigate();

  const features = [
    {
      icon: Brain,
      title: "AI-Powered Support",
      description: "Get personalized coping strategies and mental health guidance 24/7"
    },
    {
      icon: Shield,
      title: "Complete Privacy",
      description: "Your conversations and data are completely confidential and secure"
    },
    {
      icon: Users,
      title: "Professional Network",
      description: "Connect with qualified counsellors and mental health professionals"
    }
  ];

  return (
    <Layout>
      <div className="max-w-6xl mx-auto">
        {/* Hero Section */}
        <div className="text-center py-12 lg:py-20">
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <div className="flex justify-center mb-6">
              <div className="bg-gradient-to-r from-green-400 to-blue-500 p-4 rounded-full">
                <Heart className="h-12 w-12 text-white" />
              </div>
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-bold bg-gradient-to-r from-green-600 via-blue-600 to-teal-600 bg-clip-text text-transparent mb-6">
              Welcome to Your Mental Wellness Companion
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              A safe, stigma-free space where you can find support, resources, and professional help. 
              Your mental health journey starts here, and you don't have to walk it alone.
            </p>

            {/* Main Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                size="lg" 
                onClick={() => navigate('/ai-assistant')}
                className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              >
                <Brain className="mr-2 h-5 w-5" />
                Start Now - Talk to AI Assistant
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate('/resources')}
                className="border-2 border-blue-500 text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              >
                <BookOpen className="mr-2 h-5 w-5" />
                Explore Resources
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate('/book-appointment')}
                className="border-2 border-teal-500 text-teal-600 hover:bg-teal-50 px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              >
                <Calendar className="mr-2 h-5 w-5" />
                Book Appointment
              </Button>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="py-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
            Why Choose MindCare?
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card 
                  key={index} 
                  className="bg-white/70 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  <CardContent className="p-8 text-center">
                    <div className="bg-gradient-to-r from-green-400 to-blue-500 p-3 rounded-full w-fit mx-auto mb-4">
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-green-500 to-blue-600 rounded-2xl p-8 lg:p-12 text-center text-white shadow-2xl">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Ready to Take the First Step?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Your mental wellness journey begins with a single click. We're here to support you every step of the way.
          </p>
          <Button 
            size="lg"
            onClick={() => navigate('/ai-assistant')}
            className="bg-white text-green-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
          >
            <Heart className="mr-2 h-5 w-5" />
            Begin Your Journey
          </Button>
        </div>
      </div>
    </Layout>
  );
}