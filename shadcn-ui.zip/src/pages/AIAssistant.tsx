import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, MessageCircle, Activity, Users } from 'lucide-react';
import Layout from '@/components/Layout';
import ChatBot from '@/components/ChatBot';

export default function AIAssistant() {
  const features = [
    {
      icon: MessageCircle,
      title: "24/7 Support",
      description: "Get immediate support and guidance whenever you need it"
    },
    {
      icon: Activity,
      title: "Mental Health Screening",
      description: "Take validated assessments like PHQ-9 and GAD-7"
    },
    {
      icon: Users,
      title: "Professional Referrals",
      description: "Get recommendations for when to seek professional help"
    }
  ];

  return (
    <Layout>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-full">
              <Brain className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">
            AI Mental Wellness Assistant
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Your compassionate AI companion for mental health support. Get personalized coping strategies, 
            take mental health assessments, and receive guidance on when to seek professional help.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Chat Interface */}
          <div className="lg:col-span-2">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageCircle className="h-5 w-5 text-blue-600" />
                  <span>Chat with Your AI Companion</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ChatBot />
              </CardContent>
            </Card>
          </div>

          {/* Features Sidebar */}
          <div className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">How I Can Help</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {features.map((feature, index) => {
                  const Icon = feature.icon;
                  return (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0">
                        <Icon className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-800 text-sm">
                          {feature.title}
                        </h3>
                        <p className="text-xs text-gray-600 mt-1">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Crisis Resources */}
            <Card className="bg-gradient-to-r from-red-50 to-pink-50 border-red-200 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg text-red-700">Crisis Resources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm">
                  <p className="font-semibold text-red-700">If you're in crisis:</p>
                  <p className="text-red-600">• Call 988 (Suicide & Crisis Lifeline)</p>
                  <p className="text-red-600">• Text "HELLO" to 741741</p>
                  <p className="text-red-600">• Call 911 for emergencies</p>
                </div>
                <div className="text-xs text-red-500 border-t border-red-200 pt-2">
                  Remember: This AI assistant is not a replacement for professional mental health care.
                </div>
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card className="bg-gradient-to-r from-green-50 to-teal-50 border-green-200 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg text-green-700">Quick Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-green-600 space-y-2">
                  <li>• Be honest about how you're feeling</li>
                  <li>• Try the suggested coping strategies</li>
                  <li>• Take assessments when prompted</li>
                  <li>• Consider professional help if recommended</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}