import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { MapPin, Phone, Clock, Shield, Star, Calendar } from 'lucide-react';
import Layout from '@/components/Layout';

interface Counselor {
  id: number;
  name: string;
  title: string;
  specialties: string[];
  location: string;
  distance: string;
  rating: number;
  availability: string;
  phone: string;
  type: 'college' | 'private' | 'helpline';
}

export default function BookAppointment() {
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    preferredDate: '',
    preferredTime: '',
    concerns: '',
    urgency: ''
  });

  const counselors: Counselor[] = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      title: "Licensed Clinical Psychologist",
      specialties: ["Anxiety", "Depression", "Student Counseling"],
      location: "University Health Center",
      distance: "0.5 miles",
      rating: 4.9,
      availability: "Available this week",
      phone: "(555) 123-4567",
      type: "college"
    },
    {
      id: 2,
      name: "Dr. Michael Chen",
      title: "Psychiatrist",
      specialties: ["Depression", "ADHD", "Medication Management"],
      location: "Campus Medical Center",
      distance: "0.8 miles",
      rating: 4.8,
      availability: "Next available: Tomorrow",
      phone: "(555) 234-5678",
      type: "college"
    },
    {
      id: 3,
      name: "Lisa Rodriguez, LCSW",
      title: "Licensed Clinical Social Worker",
      specialties: ["Trauma", "Anxiety", "Life Transitions"],
      location: "Downtown Wellness Center",
      distance: "2.1 miles",
      rating: 4.7,
      availability: "Available next week",
      phone: "(555) 345-6789",
      type: "private"
    },
    {
      id: 4,
      name: "Crisis Support Team",
      title: "24/7 Crisis Intervention",
      specialties: ["Crisis Support", "Suicide Prevention", "Emergency Care"],
      location: "National Helpline",
      distance: "Available nationwide",
      rating: 4.9,
      availability: "Available 24/7",
      phone: "988",
      type: "helpline"
    }
  ];

  const locations = [
    "On Campus",
    "Downtown",
    "North Side",
    "South Side",
    "Online/Telehealth"
  ];

  const specialties = [
    "Anxiety",
    "Depression", 
    "Stress Management",
    "Trauma",
    "ADHD",
    "Eating Disorders",
    "Substance Abuse",
    "Relationship Issues"
  ];

  const urgencyLevels = [
    { value: "low", label: "Not urgent - within 2 weeks", color: "green" },
    { value: "medium", label: "Somewhat urgent - within a few days", color: "yellow" },
    { value: "high", label: "Urgent - within 24 hours", color: "orange" },
    { value: "crisis", label: "Crisis - immediate help needed", color: "red" }
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Appointment request submitted! You will receive a confirmation email shortly.');
  };

  const filteredCounselors = counselors.filter(counselor => {
    const locationMatch = !selectedLocation || 
      counselor.location.toLowerCase().includes(selectedLocation.toLowerCase()) ||
      selectedLocation === "Online/Telehealth";
    
    const specialtyMatch = !selectedSpecialty || 
      counselor.specialties.some(s => s.toLowerCase().includes(selectedSpecialty.toLowerCase()));
    
    return locationMatch && specialtyMatch;
  });

  return (
    <Layout>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-teal-500 to-blue-600 p-3 rounded-full">
              <Calendar className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">
            Book Confidential Appointment
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Connect with qualified mental health professionals in your area. All appointments are completely confidential and HIPAA-compliant.
          </p>
        </div>

        {/* Privacy Notice */}
        <Card className="mb-8 bg-gradient-to-r from-green-50 to-teal-50 border-green-200 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Shield className="h-6 w-6 text-green-600" />
              <div>
                <h3 className="font-semibold text-green-700">Your Privacy is Protected</h3>
                <p className="text-sm text-green-600">
                  All information is encrypted and confidential. We comply with HIPAA regulations and never share your data without your consent.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-1">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Book Your Appointment</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      required
                      className="bg-white/70"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      required
                      className="bg-white/70"
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="bg-white/70"
                    />
                  </div>

                  <div>
                    <Label htmlFor="location">Preferred Location</Label>
                    <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                      <SelectTrigger className="bg-white/70">
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.map((location) => (
                          <SelectItem key={location} value={location}>
                            {location}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="specialty">Area of Concern</Label>
                    <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                      <SelectTrigger className="bg-white/70">
                        <SelectValue placeholder="Select specialty" />
                      </SelectTrigger>
                      <SelectContent>
                        {specialties.map((specialty) => (
                          <SelectItem key={specialty} value={specialty}>
                            {specialty}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="urgency">How urgent is your need?</Label>
                    <Select value={formData.urgency} onValueChange={(value) => handleInputChange('urgency', value)}>
                      <SelectTrigger className="bg-white/70">
                        <SelectValue placeholder="Select urgency level" />
                      </SelectTrigger>
                      <SelectContent>
                        {urgencyLevels.map((level) => (
                          <SelectItem key={level.value} value={level.value}>
                            {level.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="concerns">Brief description of concerns (optional)</Label>
                    <Textarea
                      id="concerns"
                      value={formData.concerns}
                      onChange={(e) => handleInputChange('concerns', e.target.value)}
                      placeholder="This helps us match you with the right professional..."
                      className="bg-white/70"
                      rows={3}
                    />
                  </div>

                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700">
                    Submit Appointment Request
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Available Counselors */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Available Professionals</h2>
              <p className="text-gray-600">
                {filteredCounselors.length} professionals found in your area
              </p>
            </div>

            <div className="space-y-4">
              {filteredCounselors.map((counselor) => (
                <Card 
                  key={counselor.id} 
                  className="bg-white/70 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-gray-800">
                          {counselor.name}
                        </h3>
                        <p className="text-gray-600">{counselor.title}</p>
                        <div className="flex items-center space-x-2 mt-2">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span className="text-sm text-gray-600">
                            {counselor.location} • {counselor.distance}
                          </span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="flex items-center space-x-1 mb-2">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="font-semibold">{counselor.rating}</span>
                        </div>
                        <Badge 
                          variant={counselor.type === 'helpline' ? 'destructive' : 
                                  counselor.type === 'college' ? 'default' : 'secondary'}
                        >
                          {counselor.type === 'helpline' ? 'Crisis Line' : 
                           counselor.type === 'college' ? 'Campus' : 'Private'}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {counselor.specialties.map((specialty) => (
                        <Badge key={specialty} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{counselor.availability}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Phone className="h-4 w-4" />
                          <span>{counselor.phone}</span>
                        </div>
                      </div>
                      
                      <Button 
                        size="sm" 
                        className={
                          counselor.type === 'helpline' 
                            ? 'bg-red-600 hover:bg-red-700' 
                            : 'bg-teal-600 hover:bg-teal-700'
                        }
                      >
                        {counselor.type === 'helpline' ? 'Call Now' : 'Book Appointment'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* Emergency Resources */}
        <Card className="mt-12 bg-gradient-to-r from-red-50 to-pink-50 border-red-200 shadow-lg">
          <CardHeader>
            <CardTitle className="text-center text-red-700 flex items-center justify-center space-x-2">
              <Phone className="h-5 w-5" />
              <span>Crisis Resources - Available 24/7</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div>
                <h3 className="font-semibold text-red-700">Suicide & Crisis Lifeline</h3>
                <p className="text-2xl font-bold text-red-600">988</p>
                <p className="text-sm text-red-500">Call or text anytime</p>
              </div>
              <div>
                <h3 className="font-semibold text-red-700">Crisis Text Line</h3>
                <p className="text-lg font-bold text-red-600">Text HOME to 741741</p>
                <p className="text-sm text-red-500">24/7 text support</p>
              </div>
              <div>
                <h3 className="font-semibold text-red-700">Emergency</h3>
                <p className="text-2xl font-bold text-red-600">911</p>
                <p className="text-sm text-red-500">Immediate danger</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}