import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Volume2, Globe, Heart, Brain, Moon } from 'lucide-react';
import Layout from '@/components/Layout';

export default function ResourcesHub() {
  const [selectedLanguage, setSelectedLanguage] = useState('english');

  const languages = [
    { value: 'english', label: 'English', flag: '🇺🇸' },
    { value: 'hindi', label: 'हिंदी (Hindi)', flag: '🇮🇳' },
    { value: 'urdu', label: 'اردو (Urdu)', flag: '🇵🇰' },
    { value: 'spanish', label: 'Español', flag: '🇪🇸' },
    { value: 'french', label: 'Français', flag: '🇫🇷' }
  ];

  const videoResources = [
    {
      id: 1,
      title: "5-Minute Breathing Exercise for Anxiety",
      description: "Simple breathing techniques to calm your mind and reduce anxiety",
      duration: "5:23",
      category: "anxiety",
      thumbnail: "https://img.youtube.com/vi/tybOi4hjZFQ/maxresdefault.jpg",
      embedId: "tybOi4hjZFQ",
      language: "english"
    },
    {
      id: 2,
      title: "Guided Meditation for Stress Relief",
      description: "A peaceful guided meditation to help you release stress and tension",
      duration: "10:15",
      category: "meditation",
      thumbnail: "/images/meditation.jpg",
      embedId: "ZToicYcHIOU",
      language: "english"
    },
    {
      id: 3,
      title: "Understanding Depression: You're Not Alone",
      description: "Educational video about depression symptoms and coping strategies",
      duration: "8:42",
      category: "depression",
      thumbnail: "https://img.youtube.com/vi/z-IR48Mb3W0/maxresdefault.jpg",
      embedId: "z-IR48Mb3W0",
      language: "english"
    },
    {
      id: 4,
      title: "Yoga for Mental Health - Beginner Friendly",
      description: "Gentle yoga poses to improve mood and reduce stress",
      duration: "15:30",
      category: "wellness",
      thumbnail: "https://img.youtube.com/vi/hJbRpHZr_d0/maxresdefault.jpg",
      embedId: "hJbRpHZr_d0",
      language: "english"
    }
  ];

  const audioResources = [
    {
      id: 1,
      title: "Deep Sleep Relaxation",
      description: "Calming audio to help you fall asleep peacefully",
      duration: "30:00",
      category: "sleep",
      language: "english"
    },
    {
      id: 2,
      title: "Progressive Muscle Relaxation",
      description: "Guided exercise to release physical tension",
      duration: "20:00",
      category: "relaxation",
      language: "english"
    },
    {
      id: 3,
      title: "Mindfulness Bell Meditation",
      description: "Simple bell sounds for mindfulness practice",
      duration: "15:00",
      category: "mindfulness",
      language: "english"
    },
    {
      id: 4,
      title: "Nature Sounds for Focus",
      description: "Peaceful nature sounds to improve concentration",
      duration: "45:00",
      category: "focus",
      language: "english"
    }
  ];

  const categories = [
    { id: 'all', label: 'All Resources', icon: Globe },
    { id: 'anxiety', label: 'Anxiety Relief', icon: Heart },
    { id: 'depression', label: 'Depression Support', icon: Brain },
    { id: 'meditation', label: 'Meditation', icon: Brain },
    { id: 'sleep', label: 'Sleep & Rest', icon: Moon },
    { id: 'wellness', label: 'General Wellness', icon: Heart }
  ];

  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedVideo, setSelectedVideo] = useState<number | null>(null);

  const filteredVideos = selectedCategory === 'all' 
    ? videoResources 
    : videoResources.filter(video => video.category === selectedCategory);

  const filteredAudios = selectedCategory === 'all' 
    ? audioResources 
    : audioResources.filter(audio => audio.category === selectedCategory);

  return (
    <Layout>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-3 rounded-full">
              <Volume2 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">
            Mental Wellness Resources Hub
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover curated videos, guided meditations, and relaxation audios to support your mental wellness journey.
          </p>
        </div>

        {/* Language Selector */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-3">
            <Globe className="h-5 w-5 text-gray-600" />
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-48 bg-white/70 backdrop-blur-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.value} value={lang.value}>
                    <span className="flex items-center space-x-2">
                      <span>{lang.flag}</span>
                      <span>{lang.label}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className={`flex items-center space-x-2 ${
                  selectedCategory === category.id
                    ? 'bg-purple-600 text-white hover:bg-purple-700'
                    : 'text-gray-600 hover:text-purple-600'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{category.label}</span>
              </Button>
            );
          })}
        </div>

        <Tabs defaultValue="videos" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white/70 backdrop-blur-sm">
            <TabsTrigger value="videos" className="flex items-center space-x-2">
              <Play className="h-4 w-4" />
              <span>Video Resources</span>
            </TabsTrigger>
            <TabsTrigger value="audios" className="flex items-center space-x-2">
              <Volume2 className="h-4 w-4" />
              <span>Audio Resources</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="videos" className="mt-6">
            {/* Video Player */}
            {selectedVideo && (
              <Card className="mb-6 bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                      width="100%"
                      height="100%"
                      src={`https://www.youtube.com/embed/${videoResources.find(v => v.id === selectedVideo)?.embedId}`}
                      title="YouTube video player"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Video Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVideos.map((video) => (
                <Card 
                  key={video.id} 
                  className="bg-white/70 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:scale-105"
                  onClick={() => setSelectedVideo(video.id)}
                >
                  <CardContent className="p-0">
                    <div className="relative">
                      <img 
                        src={video.thumbnail} 
                        alt={video.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-200">
                        <Play className="h-12 w-12 text-white" />
                      </div>
                      <Badge className="absolute top-2 right-2 bg-black/70 text-white">
                        {video.duration}
                      </Badge>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">
                        {video.title}
                      </h3>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {video.description}
                      </p>
                      <Badge variant="outline" className="mt-2 text-xs">
                        {video.category}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="audios" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              {filteredAudios.map((audio) => (
                <Card 
                  key={audio.id} 
                  className="bg-white/70 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="text-lg">{audio.title}</span>
                      <Badge variant="outline">{audio.duration}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{audio.description}</p>
                    <div className="flex items-center justify-between">
                      <Badge className="bg-purple-100 text-purple-700">
                        {audio.category}
                      </Badge>
                      <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                        <Play className="h-4 w-4 mr-2" />
                        Play Audio
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Help Section */}
        <Card className="mt-12 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 shadow-lg">
          <CardHeader>
            <CardTitle className="text-center text-blue-700">Need More Support?</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-blue-600 mb-4">
              These resources are here to support you, but they're not a replacement for professional help.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="outline" className="border-blue-500 text-blue-600 hover:bg-blue-50">
                Talk to AI Assistant
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Book Professional Appointment
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}