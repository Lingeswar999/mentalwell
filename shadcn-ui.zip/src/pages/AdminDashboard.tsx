import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, Users, Calendar, TrendingUp, AlertTriangle, Heart } from 'lucide-react';
import Layout from '@/components/Layout';

export default function AdminDashboard() {
  // Mock data for demonstration
  const stats = {
    totalSessions: 1247,
    activeUsers: 89,
    appointmentsBooked: 156,
    resourcesAccessed: 2341,
    avgSessionDuration: "12 min",
    satisfactionRate: "94%"
  };

  const recentActivity = [
    { type: "session", description: "AI Assistant session completed", time: "2 minutes ago", severity: "low" },
    { type: "appointment", description: "Urgent appointment booked", time: "15 minutes ago", severity: "high" },
    { type: "resource", description: "Anxiety video accessed", time: "1 hour ago", severity: "low" },
    { type: "assessment", description: "High-risk assessment completed", time: "2 hours ago", severity: "high" },
    { type: "session", description: "Crisis support session", time: "3 hours ago", severity: "critical" }
  ];

  const trendData = [
    { month: "Jan", sessions: 98, appointments: 12, resources: 156 },
    { month: "Feb", sessions: 134, appointments: 18, resources: 203 },
    { month: "Mar", sessions: 167, appointments: 24, resources: 287 },
    { month: "Apr", sessions: 198, appointments: 31, resources: 342 },
    { month: "May", sessions: 234, appointments: 28, resources: 398 },
    { month: "Jun", sessions: 267, appointments: 43, resources: 456 }
  ];

  const riskAlerts = [
    { id: 1, level: "High", description: "Student reported severe depression symptoms", time: "30 min ago" },
    { id: 2, level: "Medium", description: "Increased anxiety assessments this week", time: "2 hours ago" },
    { id: 3, level: "High", description: "Crisis intervention needed", time: "4 hours ago" }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-green-100 text-green-700 border-green-200';
    }
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-purple-500 to-indigo-600 p-3 rounded-full">
              <BarChart3 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">
            Admin Dashboard
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Monitor platform usage, student wellness trends, and system performance. All data is anonymized and HIPAA-compliant.
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Sessions</p>
                  <p className="text-3xl font-bold text-blue-600">{stats.totalSessions}</p>
                </div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Users</p>
                  <p className="text-3xl font-bold text-green-600">{stats.activeUsers}</p>
                </div>
                <Heart className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Appointments Booked</p>
                  <p className="text-3xl font-bold text-purple-600">{stats.appointmentsBooked}</p>
                </div>
                <Calendar className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Resources Accessed</p>
                  <p className="text-3xl font-bold text-teal-600">{stats.resourcesAccessed}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-teal-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Session Duration</p>
                  <p className="text-3xl font-bold text-orange-600">{stats.avgSessionDuration}</p>
                </div>
                <BarChart3 className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Satisfaction Rate</p>
                  <p className="text-3xl font-bold text-pink-600">{stats.satisfactionRate}</p>
                </div>
                <Heart className="h-8 w-8 text-pink-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white/70 backdrop-blur-sm">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="alerts">Risk Alerts</TabsTrigger>
            <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Usage Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">AI Assistant Sessions</span>
                      <Badge variant="outline">78% of total usage</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Resource Hub Visits</span>
                      <Badge variant="outline">65% of users</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Appointment Bookings</span>
                      <Badge variant="outline">12% conversion rate</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Crisis Interventions</span>
                      <Badge variant="destructive">3 this week</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Top Concerns</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { concern: "Anxiety", percentage: 42, color: "bg-blue-500" },
                      { concern: "Depression", percentage: 38, color: "bg-purple-500" },
                      { concern: "Stress", percentage: 35, color: "bg-green-500" },
                      { concern: "Sleep Issues", percentage: 28, color: "bg-yellow-500" },
                      { concern: "Academic Pressure", percentage: 24, color: "bg-red-500" }
                    ].map((item) => (
                      <div key={item.concern} className="flex items-center space-x-3">
                        <div className="w-24 text-sm text-gray-600">{item.concern}</div>
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`${item.color} h-2 rounded-full`}
                            style={{ width: `${item.percentage}%` }}
                          ></div>
                        </div>
                        <div className="text-sm font-semibold">{item.percentage}%</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="trends" className="mt-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>6-Month Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {trendData.map((month) => (
                    <div key={month.month} className="grid grid-cols-4 gap-4 items-center p-4 bg-gray-50 rounded-lg">
                      <div className="font-semibold">{month.month}</div>
                      <div className="text-center">
                        <div className="text-sm text-gray-600">Sessions</div>
                        <div className="font-bold text-blue-600">{month.sessions}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-gray-600">Appointments</div>
                        <div className="font-bold text-purple-600">{month.appointments}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-gray-600">Resources</div>
                        <div className="font-bold text-green-600">{month.resources}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts" className="mt-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                  <span>Risk Alerts</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {riskAlerts.map((alert) => (
                    <div key={alert.id} className="flex items-start space-x-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                      <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <Badge 
                            variant={alert.level === 'High' ? 'destructive' : 'secondary'}
                          >
                            {alert.level} Risk
                          </Badge>
                          <span className="text-sm text-gray-500">{alert.time}</span>
                        </div>
                        <p className="text-gray-700">{alert.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity" className="mt-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className={`p-3 rounded-lg border ${getSeverityColor(activity.severity)}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">{activity.description}</p>
                          <p className="text-sm opacity-75">{activity.time}</p>
                        </div>
                        <Badge variant="outline" className="capitalize">
                          {activity.type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}