import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Send, Bot, User, Heart } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type?: 'assessment' | 'normal';
}

interface AssessmentState {
  currentQuestion: number;
  answers: number[];
  isActive: boolean;
  type: 'phq9' | 'gad7' | null;
}

export default function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your mental wellness companion. I'm here to provide support, coping strategies, and help assess how you're feeling. How can I help you today?",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [assessment, setAssessment] = useState<AssessmentState>({
    currentQuestion: 0,
    answers: [],
    isActive: false,
    type: null
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const phq9Questions = [
    "Over the last 2 weeks, how often have you been bothered by little interest or pleasure in doing things?",
    "Over the last 2 weeks, how often have you been bothered by feeling down, depressed, or hopeless?",
    "Over the last 2 weeks, how often have you been bothered by trouble falling or staying asleep, or sleeping too much?",
    "Over the last 2 weeks, how often have you been bothered by feeling tired or having little energy?",
    "Over the last 2 weeks, how often have you been bothered by poor appetite or overeating?"
  ];

  const gad7Questions = [
    "Over the last 2 weeks, how often have you been bothered by feeling nervous, anxious, or on edge?",
    "Over the last 2 weeks, how often have you been bothered by not being able to stop or control worrying?",
    "Over the last 2 weeks, how often have you been bothered by worrying too much about different things?",
    "Over the last 2 weeks, how often have you been bothered by trouble relaxing?",
    "Over the last 2 weeks, how often have you been bothered by being so restless that it's hard to sit still?"
  ];

  const copingStrategies = [
    "Try the 4-7-8 breathing technique: Inhale for 4 counts, hold for 7, exhale for 8. This can help reduce anxiety and promote relaxation.",
    "Practice grounding with the 5-4-3-2-1 technique: Name 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell, and 1 you can taste.",
    "Consider journaling your thoughts and feelings. Writing can help process emotions and gain clarity.",
    "Gentle physical activity like walking or stretching can help improve mood and reduce stress.",
    "Try progressive muscle relaxation: Tense and then relax each muscle group in your body, starting from your toes and working up."
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const addMessage = (text: string, sender: 'user' | 'bot', type?: 'assessment' | 'normal') => {
    const newMessage: Message = {
      id: Date.now(),
      text,
      sender,
      timestamp: new Date(),
      type
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const getBotResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes('stress') || input.includes('anxious') || input.includes('anxiety')) {
      return copingStrategies[0] + "\n\nWould you like me to guide you through a quick anxiety assessment to better understand how you're feeling?";
    }
    
    if (input.includes('sad') || input.includes('depressed') || input.includes('down')) {
      return copingStrategies[2] + "\n\nI'm here to support you. Would you like to take a brief depression screening to help identify the best resources for you?";
    }
    
    if (input.includes('sleep') || input.includes('tired') || input.includes('insomnia')) {
      return "Sleep difficulties can really impact our mental health. " + copingStrategies[4] + "\n\nTry to maintain a consistent sleep schedule and create a relaxing bedtime routine.";
    }
    
    if (input.includes('help') || input.includes('support')) {
      return "I'm glad you're reaching out for support. That takes courage. Here are some ways I can help:\n\n• Provide coping strategies\n• Guide you through mental health assessments\n• Suggest when to connect with a counselor\n• Share relaxation techniques\n\nWhat would be most helpful for you right now?";
    }
    
    if (input.includes('assessment') || input.includes('screening') || input.includes('test')) {
      return "I can guide you through two brief assessments:\n\n• **Depression screening (PHQ-5)** - helps identify symptoms of depression\n• **Anxiety screening (GAD-5)** - helps identify symptoms of anxiety\n\nWhich would you like to try? Just type 'depression' or 'anxiety'.";
    }
    
    if (input.includes('depression')) {
      startAssessment('phq9');
      return "I'll guide you through a brief depression screening. Please answer each question based on how you've been feeling over the last 2 weeks. Rate each on a scale of 0-3:\n\n0 = Not at all\n1 = Several days\n2 = More than half the days\n3 = Nearly every day\n\n" + phq9Questions[0];
    }
    
    if (input.includes('anxiety')) {
      startAssessment('gad7');
      return "I'll guide you through a brief anxiety screening. Please answer each question based on how you've been feeling over the last 2 weeks. Rate each on a scale of 0-3:\n\n0 = Not at all\n1 = Several days\n2 = More than half the days\n3 = Nearly every day\n\n" + gad7Questions[0];
    }
    
    if (input.includes('counselor') || input.includes('therapist') || input.includes('professional')) {
      return "Connecting with a mental health professional is a great step. Based on your needs, I'd recommend:\n\n• **For immediate support**: Visit our Book Appointment page to find local counselors\n• **For crisis situations**: Contact the crisis helpline at 1-800-HELP\n• **For ongoing support**: Consider both individual therapy and support groups\n\nWould you like me to help you find resources in your area?";
    }
    
    return "Thank you for sharing that with me. " + copingStrategies[Math.floor(Math.random() * copingStrategies.length)] + "\n\nIs there anything specific you'd like to talk about or any particular support you need right now?";
  };

  const startAssessment = (type: 'phq9' | 'gad7') => {
    setAssessment({
      currentQuestion: 0,
      answers: [],
      isActive: true,
      type
    });
  };

  const handleAssessmentAnswer = (score: number) => {
    const newAnswers = [...assessment.answers, score];
    const questions = assessment.type === 'phq9' ? phq9Questions : gad7Questions;
    
    if (assessment.currentQuestion < questions.length - 1) {
      setAssessment(prev => ({
        ...prev,
        currentQuestion: prev.currentQuestion + 1,
        answers: newAnswers
      }));
      
      addMessage(score.toString(), 'user');
      setTimeout(() => {
        addMessage(questions[assessment.currentQuestion + 1], 'bot', 'assessment');
      }, 500);
    } else {
      // Assessment complete
      const totalScore = newAnswers.reduce((sum, answer) => sum + answer, 0) + score;
      setAssessment(prev => ({ ...prev, isActive: false, answers: newAnswers }));
      
      addMessage(score.toString(), 'user');
      
      setTimeout(() => {
        let result = '';
        const assessmentType = assessment.type === 'phq9' ? 'depression' : 'anxiety';
        
        if (totalScore <= 4) {
          result = `Based on your responses, you're showing minimal ${assessmentType} symptoms. That's great! Continue with self-care practices and reach out if things change.`;
        } else if (totalScore <= 9) {
          result = `Your responses suggest mild ${assessmentType} symptoms. Consider incorporating more coping strategies into your daily routine. Our Resources page has helpful videos and techniques.`;
        } else if (totalScore <= 14) {
          result = `Your responses indicate moderate ${assessmentType} symptoms. I'd recommend connecting with a mental health professional for additional support. You can find local counselors on our Book Appointment page.`;
        } else {
          result = `Your responses suggest more significant ${assessmentType} symptoms. I strongly encourage you to reach out to a mental health professional soon. You deserve support, and help is available.`;
        }
        
        result += "\n\nRemember, this is just a screening tool and not a diagnosis. A qualified mental health professional can provide a proper assessment and treatment recommendations.";
        
        addMessage(result, 'bot');
      }, 1000);
    }
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    
    addMessage(inputText, 'user');
    const response = getBotResponse(inputText);
    
    setTimeout(() => {
      addMessage(response, 'bot');
    }, 1000);
    
    setInputText('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[600px] flex flex-col">
      {/* Chat Messages */}
      <Card className="flex-1 mb-4 bg-white/70 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-4 h-full overflow-y-auto">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.sender === 'user'
                      ? 'bg-green-600 text-white'
                      : 'bg-blue-50 text-gray-800 border border-blue-100'
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {message.sender === 'bot' && (
                      <Bot className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    )}
                    {message.sender === 'user' && (
                      <User className="h-5 w-5 text-white mt-0.5 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <p className="whitespace-pre-line">{message.text}</p>
                      <p className={`text-xs mt-1 ${
                        message.sender === 'user' ? 'text-green-100' : 'text-gray-500'
                      }`}>
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {/* Assessment Answer Buttons */}
            {assessment.isActive && (
              <div className="flex justify-center">
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 max-w-md">
                  <p className="text-sm text-gray-600 mb-3 text-center">
                    Please rate from 0-3:
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { score: 0, label: 'Not at all' },
                      { score: 1, label: 'Several days' },
                      { score: 2, label: 'More than half' },
                      { score: 3, label: 'Nearly every day' }
                    ].map((option) => (
                      <Button
                        key={option.score}
                        variant="outline"
                        size="sm"
                        onClick={() => handleAssessmentAnswer(option.score)}
                        className="text-xs hover:bg-yellow-100"
                      >
                        {option.score} - {option.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </CardContent>
      </Card>

      {/* Input Area */}
      <div className="flex space-x-2">
        <Input
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type your message here..."
          className="flex-1 bg-white/70 backdrop-blur-sm border-green-200 focus:border-green-400"
          disabled={assessment.isActive}
        />
        <Button 
          onClick={handleSendMessage}
          disabled={!inputText.trim() || assessment.isActive}
          className="bg-green-600 hover:bg-green-700 text-white"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2 mt-3 justify-center">
        <Badge 
          variant="outline" 
          className="cursor-pointer hover:bg-blue-50 text-blue-600 border-blue-200"
          onClick={() => setInputText("I'm feeling anxious")}
        >
          I'm feeling anxious
        </Badge>
        <Badge 
          variant="outline" 
          className="cursor-pointer hover:bg-green-50 text-green-600 border-green-200"
          onClick={() => setInputText("I need coping strategies")}
        >
          Need coping strategies
        </Badge>
        <Badge 
          variant="outline" 
          className="cursor-pointer hover:bg-purple-50 text-purple-600 border-purple-200"
          onClick={() => setInputText("Take assessment")}
        >
          Take assessment
        </Badge>
        <Badge 
          variant="outline" 
          className="cursor-pointer hover:bg-teal-50 text-teal-600 border-teal-200"
          onClick={() => setInputText("Find counselor")}
        >
          Find counselor
        </Badge>
      </div>
    </div>
  );
}